<?php
/* THIS IS A GENERATED FILE. DO NOT EDIT DIRECTLY. */
$generated_i18n_strings = array(
	// Reference: js/src/common/components/itemselect.js:26
	__( 'Select a %s', 'formidable' ),

	// Reference: js/src/common/components/itemselect.js:47
	__( 'Currently, there are no %s', 'formidable' ),

	// Reference: js/src/form/block.js:19
	__( 'Display a Form', 'formidable' ),

	// Reference: js/src/form/block.js:23
	__( 'contact forms', 'formidable' ),

	// Reference: js/src/form/block.js:35
	__( 'This site does not have any forms.', 'formidable' ),

	// Reference: js/src/form/formselect.js:23
	__( 'form', 'formidable' ),

	// Reference: js/src/form/formselect.js:24
	__( 'forms', 'formidable' ),

	// Reference: js/src/form/inspector.js:43
	__( 'Select Form', 'formidable' ),

	// Reference: js/src/form/inspector.js:57
	__( 'Go to form', 'formidable' ),

	// Reference: js/src/form/inspector.js:62
	__( 'Options', 'formidable' ),

	// Reference: js/src/form/inspector.js:66
	__( 'Show Form Title', 'formidable' ),

	// Reference: js/src/form/inspector.js:73
	__( 'Show Form Description', 'formidable' ),

	// Reference: js/src/form/inspector.js:80
	__( 'Minimize HTML', 'formidable' ),

	// Reference: js/src/form/inspector.js:88
	__( 'Shortcode', 'formidable' )
);
/* THIS IS THE END OF THE GENERATED FILE */
